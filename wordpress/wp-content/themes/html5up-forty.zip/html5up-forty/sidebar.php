 <div class="col_2"">
    <?php dynamic_sidebar("sidebar1"); ?>
    <br>
    <br>
	<?php last_3_posts() ?>

</div>